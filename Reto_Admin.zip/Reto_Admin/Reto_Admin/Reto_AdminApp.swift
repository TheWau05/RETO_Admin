//
//  Reto_AdminApp.swift
//  Reto_Admin
//
//  Created by Mauricio on 22/09/25.
//

import SwiftUI

@main
struct Reto_AdminApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
